package org.acts.util;

public class LinkedList<T> {

	Node<T> start;
	Node<T> end;
	Node<T> current;
	int maxCount = 0;

	// Add new Node
	public void add(T data) {
		Node<T> tempNode = new Node<T>(data);

		if (start == null)
			start = end = current = tempNode;
		else {
			end.next = tempNode;
			tempNode.previous = end;
			end = tempNode;
		}
		maxCount++;
	}

	// get first node
	public T getFirst() {
		if (start == null)
			return null;
		else {

			current = start;
			return current.data;
		}
	}

	// get last node
	public T getLast() {
		if (end == null)
			return null;
		else {

			return end.data;
		}
	}

	// get previous node
	public T getPrevious() {
		if (start == null || current.previous == null)
			return null;
		else {
			current = current.previous;
			return current.data;

		}
	}

	// get next node
	public T getNext() {
		if (start == null || current.next == null)
			return null;
		else {
			current = current.next;
			return current.data;
		}
	}

	// delete node
	public void delete(int index) {

		// If list is empty or index out of bond
		if (start == null || index > maxCount - 1) {
			return;
		}

		// if only 1 node in list
		else if (start.next == null || start == end) {
			start = end = current = null;
		}

		// if first node to delete
		else if (index == 0) {
			start = start.next;
			start.previous = null;
		}

		// if last node to delete
		else if (index == maxCount - 1) {
			end = end.previous;
			end.next = null;
		}

		// delete intermediate node
		else {
			Node<T> tempNode = start;
			for (int iTemp = 0; iTemp < index; iTemp++) {
				tempNode = tempNode.next;
			}

			tempNode.next.previous = tempNode.previous;
			tempNode.previous.next = tempNode.next;
		}
		current = start;
		maxCount--;
	}

	// Indert at index

	public void insertAtPosition(int index,T data) {
		
		Node<T> newNode = new Node<T>(data);

		// if position out of bond
		if(index > maxCount)
			return;
		
		// add in empty list
		if (start == null) {
			start = end = current = newNode;
		}
		
		
		else if(index == 0) {
			start.previous = newNode;
			newNode.next = start;
			start= newNode;
		}
		
		// 1 element in list
		else if (start.next == null && index == 1) {
			start.next = newNode;
		}
		
//		else if(index == maxCount-1) {
//			newNode.previous = end.previous;
//			newNode.next = end;
//		}
//		
		else if (index == maxCount) {
			newNode.previous = end;
			end.next = newNode;
			end = newNode;
		}
		
		
		// add intermediate node
		else {
			Node<T> positionNode = start;
			for (int iTemp = 0; iTemp < index; iTemp++) {
				positionNode = positionNode.next;
			}
			
			newNode.next = positionNode;
			newNode.previous = positionNode.previous;
			
			positionNode.previous.next = newNode;
			positionNode.previous = newNode;
	
		}
	}

	@SuppressWarnings("unchecked")
	public void sort() {
	    if (start == null || start.next == null)
	        return;

	    boolean swapped;
	    do {
	        swapped = false;
	        Node<T> currentNode = start;

	        while (currentNode.next != null) {
	            if (((Comparable<T>) currentNode.data).compareTo(currentNode.next.data) > 0) {
	                // Swap data
	                T temp = currentNode.data;
	                currentNode.data = currentNode.next.data;
	                currentNode.next.data = temp;
	                swapped = true;
	            }
	            currentNode = currentNode.next;
	        }
	    } while (swapped);
	}

}
