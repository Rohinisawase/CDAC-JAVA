package org.acts.util;

public class Entry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<String> list = new LinkedList<>();
		
		list.add("First");
		list.add("Second");
		list.add("Third");
		list.add("Fourth");
		
		list.insertAtPosition(4,"New");
			
		//list.delete(2);
		String data = list.getFirst();
		
		while(data != null) {
			System.out.println(data);
			data = list.getNext();
		}
		System.out.println("****");
		System.out.println(list.getFirst());
		System.out.println(list.getLast());
		System.out.println(list.getPrevious());
		System.out.println(list.getNext());

		}
	

}
