import org.acts.util.LinkedList;

public class Entry {

	// function to accept employee data
	public static Employee getEmployeeDetails(int type) {
		System.out.println("Enter name:");
		String name = ConsoleInput.getString();

		System.out.println("Enter Address:");
		String address = ConsoleInput.getString();

		System.out.println("Enter Age:");
		int age = ConsoleInput.getInteger();

		System.out.println("Enter Gender (true for male, false for female):");
		boolean gender = ConsoleInput.getBoolean();

		System.out.println("Enter BasicSalary:");
		double basicSal = ConsoleInput.getFloat();

		switch (type) {
		case 1: {
			System.out.println("Enter HRA:");
			double hra = ConsoleInput.getFloat();
			return new Manager(name, address, age, gender, basicSal, hra);
		}
		case 2: {
			System.out.println("Enter OverTime:");
			double overTime = ConsoleInput.getFloat();
			return new Engineer(name, address, age, gender, basicSal, overTime);
		}
		case 3: {
			System.out.println("Enter Commission:");
			double commission = ConsoleInput.getFloat();
			return new SalesPerson(name, address, age, gender, basicSal, commission);
		}
		}

		return null;
	}

	// Function to sort in ascending order buy name
//	public static void ascendingSort(LinkedList<Employee>employeeList,int count) {
//		for (int i = 0; i < count - 1; i++) {
//
//			int minIndex = i;
//
//			for (int j = i + 1; j < count; j++) {
////employeeList.getFirst().toString();
//				int result = (employeeList.getFirst().getName()).compareTo(arrEmployee[j].getName());
//				if (result > 0) {
//					minIndex = j;
//				}
//			}
//
//			Employee temp = arrEmployee[i];
//			arrEmployee[i] = arrEmployee[minIndex];
//			arrEmployee[minIndex] = temp;
//		}
//	}

	// Function to sort in descending name by name
//	public static void descendingSort(Employee[] arrEmployee, int count) {
//		for (int i = 0; i < count - 1; i++) {
//
//			int minIndex = i;
//
//			for (int j = i + 1; j < count; j++) {
//
//				int result = (arrEmployee[minIndex].getName()).compareTo(arrEmployee[j].getName());
//				if (result < 0) {
//					minIndex = j;
//				}
//			}
//
//			Employee temp = arrEmployee[i];
//			arrEmployee[i] = arrEmployee[minIndex];
//			arrEmployee[minIndex] = temp;
//		}
//	}

	public static void main(String[] args) {

		int count = 0;

		LinkedList<Employee> employeeList = new LinkedList<>();

		int choice;

		do {
			System.out.println("-----------Menu-----------");
			System.out.println("1.Add Employee");
			System.out.println("2.Display All");
			System.out.println("3.Save");
			System.out.println("4.Load");
			System.out.println("5.Sort");
			System.out.println("6. Exit");
			System.out.println("Enter Choice:");
			choice = ConsoleInput.getInteger();

			switch (choice) {
			case 1: {

				// growArrSize(arrEmployee, count);

				int subChoice;
				do {
					System.out.println("Enter Choice\n1.Manager\n2.Engineer\n3.Sales Person\n4.Exit");
					subChoice = ConsoleInput.getInteger();

					if (subChoice >= 1 && subChoice <= 3) {

						employeeList.add(getEmployeeDetails(subChoice));
					}

				} while (subChoice != 4);
			}
				break;

			case 2: {
				System.out.println("--------------------------");
				System.out.println("All Employee list");
				System.out.println("--------------------------");

				Employee employeeData = employeeList.getFirst();

				while (employeeData != null) {
					System.out.println(employeeData);
					employeeData = employeeList.getNext();
					System.out.println("--------------------------");

				}

			}

				break;
			case 5: {
				int ch;

				do {

					System.out.println("\nEnter Choice\n1.Sort by name\n2.Sort by designation\n3.Exit");
					ch = ConsoleInput.getInteger();

					switch (ch) {

					case 1: {
//
//						System.out.println("\nEnter Choice\n1.Sort by Ascending\n2.Sort by Descending");
//						int sortChoice = ConsoleInput.getInteger();
//
//						if (sortChoice == 1) {
//							ascendingSort(employeeList,count);
//						} else {
//							descendingSort(employeeList,count);
//						}
//
//						System.out.println("---------------------------------------");
//						System.out.println("All employee in Sorted order");
//						System.out.println("---------------------------------------");
//
//						for (int emp = 0; emp < count; emp++) {
//
//							System.out.println(arrEmployee[emp].getName());
//						}
						employeeList.sort();

						Employee employeeData = employeeList.getFirst();

						while (employeeData != null) {
							System.out.println(employeeData);
							employeeData = employeeList.getNext();
							System.out.println("--------------------------");

						}

					}
						break;

					case 2: {

						System.out.println("\nEnter Designation \n1.Manager\n2.Engineer\n3.SalesPerson");
						int sortDesgChoice = ConsoleInput.getInteger();

						if (sortDesgChoice == 1) {

							System.out.println("----------------------");
							System.out.println("All Managers Names");
							System.out.println("----------------------");

							Employee employeeData = employeeList.getFirst();

							while (employeeData != null) {
								if (employeeData instanceof Manager) {
									System.out.println(employeeData.getName());
									employeeData = employeeList.getNext();
									System.out.println("--------------------------");
								}

							}

						} else if (sortDesgChoice == 2) {

							System.out.println("----------------------");
							System.out.println("All Engineers Names");
							System.out.println("----------------------");

							Employee employeeData = employeeList.getFirst();

							while (employeeData != null) {
								if (employeeData instanceof Engineer) {
									System.out.println(employeeData.getName());
									employeeData = employeeList.getNext();
									System.out.println("--------------------------");
								}
							}

						} else if (sortDesgChoice == 3) {

							System.out.println("----------------------");
							System.out.println("All Sales Person Names");
							System.out.println("----------------------");

							Employee employeeData = employeeList.getFirst();

							while (employeeData != null) {
								if (employeeData instanceof SalesPerson) {
									System.out.println(employeeData.getName());
									employeeData = employeeList.getNext();
									System.out.println("--------------------------");
								}
							}

						}
					}
						break;

					}

				} while (ch != 3);
			}
				break;

			}
		} while (choice != 6);
	}

}
